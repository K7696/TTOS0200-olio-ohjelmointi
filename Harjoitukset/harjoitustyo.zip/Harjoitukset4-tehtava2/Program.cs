﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Harjoitukset4_tehtava2
{
    public class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}
