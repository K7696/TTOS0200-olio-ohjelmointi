﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Harjoitukset5_tehtava2
{
    public class Artisti : Person
    {
        #region Properties

        public string Genre { get; set; }

        #endregion Properties
    }
}
