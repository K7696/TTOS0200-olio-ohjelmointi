﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Harjoitukset5_tehtava2
{
    public abstract class Person
    {
        #region Properties

        public string Nimi { get; set; }

        #endregion Properties
    }
}
