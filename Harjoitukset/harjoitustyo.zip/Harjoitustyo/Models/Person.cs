﻿namespace Harjoitustyo
{
    public class Person
    {
        #region Properties

        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Email { get; set; }
        public string Phonenumber { get; set; }

        #endregion Properties
    }
}
